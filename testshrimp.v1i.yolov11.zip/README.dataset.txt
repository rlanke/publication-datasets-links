# testshrimp > 2024-03-22 12:29am
https://universe.roboflow.com/as-pg9mr/testshrimp

Provided by a Roboflow user
License: CC BY 4.0

